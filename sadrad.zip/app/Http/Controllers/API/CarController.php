<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Resources\CarCollection;
use App\Http\Resources\Car as CarResource;
use App\Traits\CanUpload;
use App\Car;
use App\TypesCars;

class CarController extends Controller
{
    use CanUpload;
    public function index($local)
    {
        $cars = Car::with('typesCars')->where('language',$local)->get();
        dd($cars);
        return (new CarCollection($cars));
    }
    public function store(Request $request ,TypesCars $TypesCars)
    {
       
       
        $car = new Car();
        $car->type_carid = $TypesCars->id;
        $car->brand_car = $request->get('brand_car');
        $car->model = $request->get('model');
        $car->maximum_weight = $request->get('maximum_weight');
        $car->number_of_persons = $request->get('number_of_persons');
        $car->Aircondtion = $request->get('Aircondtion');
        $car->language = $request->get('language');
        if ($request->file('image')){
            $car->image = $this->upload($request->file('image'), 'cars')->getFileName();
        }
        $car->save();
        return response()->json(['saved' => true,'data' => $car], 200);
    }
    public function update(Request $request , $id)
    {
        
        $car = Car::find($id);
        $car->type_car = $request->get('type_car');
        $car->brand_car = $request->get('brand_car');
        $car->model = $request->get('model');
        $car->maximum_weight = $request->get('maximum_weight');
        $car->number_of_persons = $request->get('number_of_persons');
        $car->Aircondtion = $request->get('Aircondtion');
        if ($request->file('image')){
            $car->image = $this->upload($request->file('image'), 'cars')->getFileName();
        }
        $car->save();
        return response()->json(['updated' => true,'data' => $car], 200);
    }
    
}
