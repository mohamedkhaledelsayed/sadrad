<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();    
    
// });


Route::post('users/register',"Auth\Api\APIRegisterController@register");
Route::post('users/login',"Auth\Api\APILoginController@login");



 

Route::middleware('jwt.auth')->get('/users', function (Request $request) {
    return auth()->user();    
    
});
Route::get('cars/{local}', 'API\CarController@index');


Route::group(['middleware' => ['ChangeLanguage']], function () {
    Route::post('typescars','API\TypesCarsController@index');  
    Route::post('car/store/{TypesCars}','API\CarController@store');
    Route::post('car/update/{id}','API\CarController@update');
});
